unsigned short internet_checksum(unsigned short *addr, int count);

unsigned char* swap_bytes(unsigned char *data, unsigned int data_length);